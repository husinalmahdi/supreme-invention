<?php

namespace App\Models;

use CodeIgniter\Model;

class models_ukuran_gambar extends Model
{
    protected $table = 'ukuran_gambar_produk';

    protected $primaryKey = 'id_ukuran';

  public function Pilih($id)
  {
       $query = $this->db->table($this->table)->getWhere(['id_unik_ukuran' => $id]);
    
       return $query;
  }
  public function Simpan($data)
  {
      $query = $this->db->table($this->table)->insert($data);
      return $query;
  }
  public function HapusUkuran($id)
  {
      $query = $this->db->table($this->table)->delete(array('id_unik_ukuran' => $id));
      return $query;
  }
}
