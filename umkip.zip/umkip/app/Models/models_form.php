<?php

namespace App\Models;

use CodeIgniter\Model;

class models_form extends Model
{
    protected $table = 'form_ukmki';

    protected $primaryKey = 'id';

  
    public function getAll()
  {
    $data = $this->select(['id','id_unik','link','nama_ukmki', 'jenis_ukm', 'gambar_logo','nama_asli', 'nama_panggilan', 'penjelasan', 'instagram','twitter','no_wa','insert_at','nama_produk','keterangan_produk','harga_produk','GROUP_CONCAT(gambar_produk.gambar_produk ORDER BY gambar_produk.id_gambar ASC SEPARATOR ";") as gambar'])->
    join('gambar_produk','form_ukmki.id_unik = gambar_produk.id_unik_gambar','inner')->groupBy('form_ukmki.id')->orderBy('id', 'DESC');
    return $data; 
  }
  public function HapusData($id)
  {
      $query = $this->delete(array('id_unik' => $id));
      return $query;
  }
  public function getHasil($cari){
      
     $data1 = $this->like('nama_ukmki', $cari)->orlike('jenis_ukm', $cari); 
             return $data1 ->countAllResults();
      }
        
  public function Pilih($id,$link)
  {
    

       $query = $this->select(['id','id_unik','link','nama_ukmki', 'jenis_ukm', 'gambar_logo','nama_asli', 'nama_panggilan', 'penjelasan', 'instagram','twitter','no_wa','insert_at','nama_produk','keterangan_produk','harga_produk','GROUP_CONCAT(gambar_produk.gambar_produk ORDER BY gambar_produk.id_gambar ASC SEPARATOR ";") as gambar'])-> join('gambar_produk','form_ukmki.id_unik = gambar_produk.id_unik_gambar','inner')->groupBy('form_ukmki.id')->getWhere(['link' => $id, 'id_unik' => $link ]);
       return $query;
  }
  public function Pilih_gambar_satu($id)
  {
    
       $data = $this->select(['id','id_unik','link','nama_ukmki', 'jenis_ukm', 'gambar_logo','nama_asli', 'nama_panggilan', 'penjelasan', 'instagram','twitter','no_wa','insert_at','GROUP_CONCAT(gambar_produk.gambar_produk ORDER BY gambar_produk.id_gambar ASC SEPARATOR ";") as gambar'])->
       join('gambar_produk','form_ukmki.id_unik = gambar_produk.id_unik_gambar','inner')->groupBy('form_ukmki.id')->getWhere(['id_unik' => $id]);;
       
       return $data;
  }
  public function edit_data($id,$data)
    {
        $query = $this->db->table($this->table)->update($data, array('id' => $id));
        return $query;
    }    
  public function pilih_gambar($id)
  {
       $query = $this->getWhere(['id_unik' => $id]);
    
       return $query;
  }
    
  public function SimpanBlog($data)
  {
      $query = $this->db->table($this->table)->insert($data);
      return $query;
  }
  

 }
