<?php

namespace App\Models;

use CodeIgniter\Model;

class models_gambar extends Model
{
    protected $table = 'gambar_produk';

    protected $primaryKey = 'id';

  
    public function getAll()
  {
    return $this->findAll(); 
  }
  public function HapusData($id)
  {
      $query = $this->db->table($this->table)->delete(array('id' => $id));
      return $query;
  }
  
  public function Pilih($id)
  {
       $query = $this->db->table($this->table)->getWhere(['id' => $id]);
    
       return $query;
  }

  public function pilih_gambar($id)
  {
       $query = $this->db->table($this->table)->getWhere(['id_unik_gambar' => $id]);
    
       return $query;
  }
    
  public function Simpan($data)
  {
      $query = $this->db->table($this->table)->insert($data);
      return $query;
  }
  public function HapusGambar($id)
  {
      $query = $this->db->table($this->table)->delete(array('id_gambar' => $id));
      return $query;
  }
    public function HapusSemuaGambar($id)
  {
      $query = $this->db->table($this->table)->delete(array('id_unik_gambar' => $id));
      return $query;
  }
  public function PilihGambar($id)
  {
       $query = $this->getWhere(['id_gambar' => $id]);
       return $query;
  }
 }
