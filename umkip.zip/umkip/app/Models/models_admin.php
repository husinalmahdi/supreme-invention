<?php
 
namespace App\Models;
 
use CodeIgniter\Model;
 
class models_admin extends Model
{
    protected $table = "admin_umkip";
    protected $primaryKey = "username";
    protected $returnType = "object";
    protected $useTimestamps = true;
    protected $allowedFields = ['username', 'password'];
}