<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\models_form;
use App\Models\models_gambar;
use App\Models\models_ukuran_gambar;
class Home extends BaseController
{
    public function index()
    {
        $model = new models_form();

        helper('form');
        $data['list'] = $model->getAll()->paginate(2, 'pagination');
        $data['pager'] = $model->pager;
        $data['nomor'] = nomor($this->request->getVar('page_pagination'), 2);
        return view('home_page',$data);
    }

    public function cari()
    {

         $model = new models_form();
         $cari = $this->request->getGet('cari');
         $jumlah = $model ->getHasil($cari);
         
         if($jumlah > 0){
     
            $data['hasil'] = "Hasil pencarian dari <b >$cari</b> ditemukan sebanyak <b>$jumlah</b>";

         }
         else{
             
            $data['hasil'] = "Data tidak ditemukan";
              
         }
      
     
         $data1 = $model->like('nama_ukmki', $cari)->orlike('jenis_ukm', $cari); 
         $data['list'] = $data1->getAll()->paginate(10, 'pagination');
        $data['pager'] = $model->pager;
        $data['nomor'] = nomor($this->request->getVar('page_pagination'), 10);
         return view('hasil_pencarian', $data);
         
    }
   
    public function price()
    {
        return view('pricing');
    }

    public function about()
    {
        return view('about');
    }

    public function product()
    {
        $model = new models_form();
        $data['list'] = $model->getAll();
        return view('products', $data);
    }

    public function faq()
    {
        return view('faq');
    }

    public function contact()
    {
        return view('contact');
    }
    public function simpan(){
           
        $model = new models_form();
         if ($this->request->getMethod() !== 'post') {
             return redirect()->to('upload');
         }

         
         $validation= $this->validate([
             'file_upload' => "uploaded[file_upload]|mime_in[file_upload,image/jpg,image/x-png,image/jpeg,image/gif,image/png]|max_size[file_upload,100000],",
         ]);
         
         if ($validation == FALSE) {
            session()->setFlashdata('berhasil', 'Gambar harus dimasukkan');
            return redirect()->back();
         } else {
             $upload_gambar = $this->request->getFile('file_upload');
         
              $data_artikel = array(
                 'nama_ukmki'  => $this->request->getPost('nama_ukmki'),
                 'jenis_ukm' => $this->request->getPost('jenis_ukm'),
                 'nama_asli' => $this->request->getPost('nama_asli'),
                 'nama_panggilan' => $this->request->getPost('nama_panggilan'),
                 'alasan' => $this->request->getPost('alasan'),
                 'instagram' => $this->request->getPost('instagram'),
                 'facebook' => $this->request->getPost('facebook'),
                 'no_wa' => $this->request->getPost('no_wa'),
                  );
                  
             $namaacak_gambar = $upload_gambar->getRandomName();
             $upload_gambar->move('assets/images', $namaacak_gambar);
             $data_artikel['gambar_logo'] = $namaacak_gambar;
             
          
                
             if(preg_match("/(http)/",$data_artikel["alasan"]) ||preg_match("/(https)/",$data_artikel["alasan"])) {
                return redirect()->back()->with('berhasil', 'Data Anda tidak valid!!');
             }
             else{
             $model->SimpanBlog($data_artikel);
             return redirect()->back()->with('berhasil', 'Data Berhasil di Simpan');
             }
         }
       }
       public function view($id,$link){
        $model = new models_form();
        $model_gambar = new models_gambar();
        $model_ukuran_gambar = new models_ukuran_gambar();
        $dt = $model->Pilih($id,$link)->getRow();
        $route = $dt -> id_unik; 
        $data['list'] = $model->Pilih($id,$link)->getRow();
        $data['ukuran'] = $model_ukuran_gambar->Pilih($route)->getRow();
        $data['gambar'] = $model_gambar->getAll();
        return view('vw_view_product',$data);
       }
}
