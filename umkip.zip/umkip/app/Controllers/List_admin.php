<?php 
namespace App\Controllers;
use CodeIgniter\Controller;
use App\Models\models_form;
use App\Models\models_gambar;
use App\Models\models_ukuran_gambar;

class list_admin extends Controller
{
    public function index()
    {    
        helper('form');
        $model = new models_form();
        if(session()->get('username')){
        $data['list'] = $model->getAll()->findAll();
        return view('vw_list_admin',$data);
        }
        else{
            die("Anda bukan Admin!!");
        }
    }
             public function store()
    { 
        helper(['form', 'url']); 
		$data = $_POST['image'];
		if(!empty($data)){
			
			$img_arr_a = explode(";", $data);
			$img_arr_b = explode(",", $img_arr_a[1]);
 
			$data = base64_decode($img_arr_b[1]);
			$image_name = time() . '.png';
			$path =  WRITEPATH . 'uploads/'. $image_name;

			file_put_contents($path, $data);
			
			$saveData = [
			 'gambar'  => $image_name,
			 ];
			 
			 $model = new models_form();
			$save = $model->insert($saveData);

			return json_encode(['status' => 1, 'message' => "Image uploaded successfully"]);
		}
		
    }
    
    public function simpan(){
           
        $model = new models_form();
         if ($this->request->getMethod() !== 'post') {
             return redirect()->to('upload');
         }

         
         $validation= $this->validate([
             'file_upload' => "uploaded[file_upload]|mime_in[file_upload,image/jpg,image/x-png,image/jpeg,image/gif,image/png]|max_size[file_upload,100000],",
         ]);
         
         if ($validation == FALSE) {
            session()->setFlashdata('berhasil', 'Gambar harus dimasukkan');
            return redirect()->back();
         } else {
             $upload_gambar = $this->request->getFile('file_upload');
         
              $data_artikel = array(
                 'id_unik'  => $this->request->getPost('id'),
                 'nama_ukmki'  => $this->request->getPost('nama_ukmki'),
                 'link' => str_replace(' ', '-',$this->request->getPost('nama_ukmki')),
                 'jenis_ukm' => $this->request->getPost('jenis_ukm'),
                 'nama_asli' => $this->request->getPost('nama_asli'),
                 'nama_panggilan' => $this->request->getPost('nama_panggilan'),
                 'penjelasan' => $this->request->getPost('penjelasan'),
                 'instagram' => $this->request->getPost('instagram'),
                 'twitter' => $this->request->getPost('twitter'),
                 'no_wa' => $this->request->getPost('no_wa'),
                  );
            
             $namaacak_gambar = $upload_gambar->getRandomName();
             $upload_gambar->move('assets/images', $namaacak_gambar);
             $data_artikel['gambar_logo'] = $namaacak_gambar;
             
          
                
             if(preg_match("/(http)/",$data_artikel["penjelasan"]) ||preg_match("/(https)/",$data_artikel["penjelasan"])) {
                return redirect()->back()->with('berhasil', 'Data Anda tidak valid!!');
             }
             else{
             $model->SimpanBlog($data_artikel);
             $id = $this->request->getPost('link');
             return redirect()->to("./list_admin/view_gambar/$id")->with('berhasil', 'Data Berhasil di Simpan');
             }
         }
    }
    
	public function crop()
	{
		$data = $this->request->getVar('image');
        dd($data);
        list($type, $data) = explode(';', $data);
        list(, $data)      = explode(',', $data);

        $data = base64_decode($data);
        $image_name = time() . '.png';
        $path =  "images/" . $image_name;

        file_put_contents($path, $data);

        return json_encode(['status' => 1, 'message' => "Image uploaded successfully"]);
	}   
    public function simpan_gambar(){
           
        $model = new models_gambar();
        $model_ukuran = new models_ukuran_gambar();
         if ($this->request->getMethod() !== 'post') {
             return redirect()->to('upload');
         }

         
         $validation= $this->validate([
             'file_upload' => "uploaded[file_upload]|mime_in[file_upload,image/jpg,image/x-png,image/jpeg,image/gif,image/png]|max_size[file_upload,100000],",
             'nama_produk' => [
                'rules' => 'required',
                'gambar' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
            'keterangan_produk' => [
                'rules' => 'required',
                'gambar' => [
                    'required' => '{field} Harus diisi',
                ]
            ],
            'harga_produk' => [
                'rules' => 'required',
                'gambar' => [
                    'required' => '{field} Harus diisi'
                ]
            ],
           
         ]);
         
         if ($validation == FALSE) {
            session()->setFlashdata('gambar', $this->validator->listErrors());
            return redirect()->back();
         } else {
             $upload_gambar = $this->request->getFile('file_upload');
         
              $data_artikel = array(
                 'id_unik_gambar'  => $this->request->getPost('id'),
                 'nama_produk'  => $this->request->getPost('nama_produk'),
                 'keterangan_produk'  => $this->request->getPost('keterangan_produk'),
                 'harga_produk'  => $this->request->getPost('harga_produk')
                 
                  );
              $data_ukuran = array(
                 'id_unik_ukuran'  => $this->request->getPost('id_unik_ukuran'),
                 'panjang_gambar'  => $this->request->getPost('panjang_gambar'),
                 'lebar_gambar'  => $this->request->getPost('lebar_gambar'),
                  );
             $namaacak_gambar = $upload_gambar->getRandomName();
             $upload_gambar->move('assets/images', $namaacak_gambar);
             $data_artikel['gambar_produk'] = $namaacak_gambar;
             
             $model->Simpan($data_artikel);
             $model_ukuran->Simpan($data_ukuran);
             return redirect()->back()->with('gambar', 'Gambar Berhasil di Simpan');

         }
    }
    public function view($id,$link){
    $model = new models_form();
    $model_ukuran = new models_ukuran_gambar();
    if(session()->get('username')){
        $data['list'] = $model->Pilih($id,$link)->getRow();
        $data['ukuran'] = $model_ukuran->Pilih($id)->getRow();

        return view('list_one_data',$data);
        }
        else{
            die("Anda bukan Admin!!");
      }
    }
    public function form_edit($id,$link){
    $model = new models_form();
    $model_ukuran = new models_ukuran_gambar();
    $model_gambar = new models_gambar();
    helper('form');
    if(session()->get('username')){
        $data['list'] = $model->Pilih($id,$link)->getRow();
        $data['ukuran'] = $model_ukuran->Pilih($id)->getRow();
        return view('form_edit',$data);
        }
        else{
            die("Anda bukan Admin!!");
      }
    }
    
    
    public function edit(){
        $model = new models_form();
        if ($this->request->getMethod() !== 'post') {
            return redirect()->to('blog');
        }
        
        $id = $this->request->getPost('id');
        $link = str_replace(' ', '-',$this->request->getPost('nama_ukmki'));
        $route = $this->request->getPost('id_unik');
        
        $validation = $this->validate([
            'file_upload' => "uploaded[file_upload]|mime_in[file_upload,image/jpg,image/x-png,image/jpeg,image/gif,image/png]|max_size[file_upload,100000],",
        ]);
        if ($validation == FALSE) {
            
        $data = array(
            'nama_ukmki'  => $this->request->getPost('nama_ukmki'),
            'link' => str_replace(' ', '-',$this->request->getPost('nama_ukmki')),
            'jenis_ukm' => $this->request->getPost('jenis_ukm'),
            'nama_asli' => $this->request->getPost('nama_asli'),
            'nama_panggilan' => $this->request->getPost('nama_panggilan'),
            'penjelasan' => $this->request->getPost('penjelasan'),
            'instagram' => $this->request->getPost('instagram'),
            'twitter' => $this->request->getPost('twitter'),
            'no_wa' => $this->request->getPost('no_wa'),

        );
        
        } else {
            
        $data = array(
            'nama_ukmki'  => $this->request->getPost('nama_ukmki'),
            'link' => str_replace(' ', '-',$this->request->getPost('nama_ukmki')),
            'jenis_ukm' => $this->request->getPost('jenis_ukm'),
            'nama_asli' => $this->request->getPost('nama_asli'),
            'nama_panggilan' => $this->request->getPost('nama_panggilan'),
            'penjelasan' => $this->request->getPost('penjelasan'),
            'instagram' => $this->request->getPost('instagram'),
            'twitter' => $this->request->getPost('twitter'),
            'no_wa' => $this->request->getPost('no_wa'),
        );
        


        
        $upload = $this->request->getFile('file_upload');
        if($upload->getError() == 0 ){
        //update video
          $namaacak_gambar = $upload->getRandomName();
          $data['gambar_logo'] = $namaacak_gambar;
      
        }

          
        } 

        $model->edit_data($id,$data);
        
        $dt = $model->Pilih($link,$route)->getRow();
        $gambar = $dt -> gambar_logo;
        $path = 'assets/images/';
        $upload = $this->request->getFile('file_upload');
        if($upload->getError() == 0 ){
          @unlink($path.$gambar);
          $upload->move('assets/images', $namaacak_gambar);
        }
        return redirect()->to("./list_admin/View_gambar/$route")->with('berhasil', 'Data Berhasil di Ubah');
    }
    public function hapus($id){
        $model = new models_form();
        $model_gambar = new models_gambar();
        $model_ukuran = new models_ukuran_gambar();
        
        $dt_gambar = $model->Pilih_gambar_satu($id)->getRow();
        $dt_gambar_produk = $model_gambar->pilih_gambar($id)->getRow();
        $model->HapusData($id);
        $model_ukuran->HapusUkuran($id);
        $model_gambar->HapusSemuaGambar($id);
        
        $gambar = $dt_gambar->gambar_logo;
        $gambar_produk = $dt_gambar_produk->gambar_produk;
        
        $path = '/assets/images/';
        @unlink($path.$gambar);
        @unlink($path.$gambar_produk);
        return redirect()->to('./list')->with('berhasil', 'Data Berhasil di Hapus');
    }

    public function hapus_gambar($id){
        $model_gambar = new models_gambar();
        $dt = $model_gambar->PilihGambar($id)->getRow();
        $model_gambar->HapusGambar($id);
        $gambar = $dt->gambar_produk;
        $path = '/assets/images/';
        @unlink($path.$gambar);
        return redirect()->back();
    }

    public function View_gambar($id){
        helper('form');
        $model = new models_form();
        $model_gambar = new models_gambar();
        if(session()->get('username')){
        $data['list'] = $model->pilih_gambar($id)->getRow();
        $data['gambar'] = $model_gambar-> getAll();
     
        return view('form_gambar',$data);
        }
        else{
            die("Anda bukan Admin!!");
        }
    }
}