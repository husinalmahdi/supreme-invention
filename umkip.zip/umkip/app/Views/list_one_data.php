<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/assets/css/admin.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<title>Admin</title>
</head>

<body>
	<main class="main">


		<div class="content">
			<h1>List detail data</h1>


			<table class="table">
				<thead>
					<tr>
						<th>Nama Asli Pedagang</th>
                        <th>Nama Panggilan Pedagang</th>
						<th>Nama Usaha</th>
						<th>Jenis Usaha</th>
                        <th>Alasan</th>
                        <th>Akun instagram</th>
                        <th>Akun facebook</th>
                        <th>Nomor Whatsapp</th>
                        <th>Tanggal upload</th>
                        <th>Gambar Logo</th>
						<th>Gambar Produk</th>
                        <th></th>
					</tr>
				</thead>
				<tbody>
			
					<tr>
						<td>
							<div><?=$list->nama_asli;?></div>
						</td>
						<td>
						<div><?=$list->nama_panggilan;?></div>
						</td>
                        <td>
						<div><?=$list->nama_ukmki;?></div>
						</td>
                        <td>
						<div><?=$list->jenis_ukm;?></div>
						</td>
                        <td>
						<div><?=$list->penjelasan;?></div>
						</td>
                        <td>
						<div><?=$list->instagram;?></div>
						</td>
                        <td>
						<div><?=$list->twitter;?></div>
						</td>
                        <td>
						<div><?=$list->no_wa;?></div>
						</td>
                        <td>
						<div><?=$list->insert_at;?></div>
						</td>
                        <td>
                         <div> <img src="<?= base_url('assets/images/' . $list->gambar_logo); ?>" width="200"></div>
                        </td>
						<?php $array_gambar = explode(';', $list->gambar);?>
						<td>
					   <?php foreach($array_gambar as $ar_ga) {?>
						<div> <img src="<?= base_url('assets/images/' . $ar_ga); ?>" width="200"></div>
                      <?php }?>
                        </td>
					</tr>
					
					
				</tbody>
			</table>
		</div>
	</main>
</body>

</html>