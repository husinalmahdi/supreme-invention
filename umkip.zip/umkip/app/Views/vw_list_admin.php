<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/css/admin.css">
<link rel="stylesheet" href="https://getbootstrap.com/docs/5.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<title>Admin</title>
</head>

<body>
	<main class="main">

	<div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark" style="width: 280px; min-height:600px">
    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
      <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
      <span class="fs-4">UKM KI</span>
    </a>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
      <li class="nav-item">
        <a href="#" class="nav-link active" aria-current="page">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#home"/></svg>
          Home
        </a>
      </li>


      <li>
        <a href="#" class="nav-link text-white">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#grid"/></svg>
          Products
        </a>
      </li>
      <li>
        <a href="#" class="nav-link text-white">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"/></svg>
          Logout
        </a>
      </li>
    </ul>
    <hr>

  </div>

  <div class="brand">
	</div>
		<div class="content">
			<h1>List data form</h1>
			
			<button type="button" class="btn btn-secondary btn-lg mb-2" id="myBtn">Tambah Data</button>

			<table class="table">
				<thead>
					<tr>
						<th>Nama Pedagang</th>
						<th>Nama Usaha</th>
						<th style="width: 25%;" class="text-center">Action</th>
					</tr>
				</thead>
				<tbody>
				<?php $nomor = 1;
                    foreach($list as $row){ ?>
					<tr>
						<td>
							<div><?= $row['nama_asli']; ?></div>
							
							<div class="text-gray"><small>12 Jan 2021<small></div>
						</td>
						<td>
						<div><?= $row['nama_ukmki']; ?></div>
						</td>
						<td>
							<div class="action">
								<a href="list_admin/view/<?=$row['link'];?>/<?=$row['id_unik'];?>" class="button button-small" role="button">View</a>
								<!-- <a href="#" class="button button-small" role="button">Edit</a> -->
								<a href="list_admin/hapus/<?=$row['id_unik'];?>" class="button button-small button-danger" role="button">Delete</a>
								<a href="list_admin/form_edit/<?=$row['link'];?>/<?=$row['id_unik'];?>" class="button button-small button-danger" role="button">Edit</a>
								
							</div>
						</td>
					</tr>
					<?php }?>
					
				</tbody>
			</table>

		</div>
	</main>
	
<div id="myModal" class="modal">

<!-- Modal content -->
<div class="modal-content" style="max-height:1000px;">
  <span class="close">&times;</span>
  <div id="svg_wrap"></div>
  <h1 class="text-center">FORM INPUT</h1>

<?=form_open_multipart(base_url('List_admin/simpan'),'id="validasi"');?>
 <?= csrf_field(); ?>
<section>
<p>Informasi usaha</p>

<input type="hidden" name="id" value="<?= md5(microtime(true).mt_Rand())?>"/>
<input type="text"class="mt-2" placeholder="Nama" name="nama_asli" id="nama_asli"  />
<input type="text" class="mt-2"placeholder="Nama Panggilan" name="nama_panggilan" id="nama_panggilan"  />
<input type="text" class="mt-2"placeholder="Nama Usaha" name="nama_ukmki"id="nama_usaha"  />
<input type="text"class="mt-2" placeholder="Jenis Usaha" name="jenis_ukm"id="jenis_ukm"  />

</section>

<section>
<p>Penjelasan usaha</p>
<textarea class="form-control" style="height:150px;"id="exampleFormControlTextarea1" name="penjelasan" id="alasan" ></textarea>
</section>

<section>
<p>Akun Media Sosial</p>
<input type="text" class="mt-2" placeholder="Akun Instagram"name="instagram" />
<input type="text" class="mt-2"  placeholder="Akun Twitter" name="twitter" />
<input type="number" class="mt-2" placeholder="Nomor Whatsapp"name="no_wa"id="no_wa"  />

</section>

<section>
<p>Logo Usaha</p>
<input type="file" name="file_upload" id="gambar" />

</section>

<section>
<p>General condtitions</p>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
</section>

<div class="center">
<div class="button" id="prev">&larr; Previous</div>
<div class="button" id="next">Next &rarr;</div>
<button class="button " id="submit"onclick="validation()">Kirim formulir</button> 

</div>
</form>
</div>

</div>
<script src="/js/script.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.17.2/dist/sweetalert2.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@9.17.2/dist/sweetalert2.min.css">
	<script src="https://getbootstrap.com/docs/5.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

</body>

</html>