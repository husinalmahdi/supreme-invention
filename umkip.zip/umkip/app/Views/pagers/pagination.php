
<?php $pager->setSurroundCount(2) ?>
<br />
<nav aria-label="Page navigation">
    <ul class="pagination justify-content-center">
        
 
        <?php foreach ($pager->links() as $link) : ?>
            <li class="page-item <?= $link['active'] ? 'active"' : '' ?>">
                <a class="page-link" href="<?= $link['uri'] ?>">
                    <?= $link['title'] ?>
                </a>
            </li>
        <?php endforeach ?>
 
    </ul>
</nav>

<style>
    .pagination li a.page-link
    {

      padding:5px 18px !important;
       background-color: transparent !important;
      border: 3px solid #2ecc71;
      border-radius:10px!important;
     line-height: 30px;
     text-align: center;
     margin: auto 5px;
    }
.page-item.active .page-link {
    z-index: 3;
    color: #fff;
    background-color: transparent !important;
    box-shadow: rgba(149, 157, 165, 0.2) 0px 8px 24px;
}
    

</style>