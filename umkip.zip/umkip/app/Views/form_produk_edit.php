<!DOCTYPE html>
<html lang="en">

<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="/css/admin.css">
<link rel="stylesheet" href="https://getbootstrap.com/docs/5.0/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
<title>Admin</title>
</head>

<body>
	<main class="main">
		<div class="d-flex flex-column flex-shrink-0 p-3 text-white bg-dark" style="width: 280px; min-height:600px">
    <a href="/" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto text-white text-decoration-none">
      <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
      <span class="fs-4">UKM KI</span>
    </a>
    <hr>
    <ul class="nav nav-pills flex-column mb-auto">
      <li class="nav-item">
        <a href="#" class="nav-link text-white" aria-current="page">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#home"/></svg>
          Home
        </a>
      </li>


      <li>
        <a href="#" class="nav-link text-white">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#grid"/></svg>
          Products
        </a>
      </li>
      
      <li class="nav-item">
        <a href="#" class="nav-link active" aria-current="page">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#home"/></svg>
          Update
        </a>
      </li>
      
      <li>
        <a href="#" class="nav-link text-white">
          <svg class="bi me-2" width="16" height="16"><use xlink:href="#people-circle"/></svg>
          Logout
        </a>
      </li>
    </ul>
    <hr>

  </div>

		<div class="content">
			<h1>Edit Umkm</h1>

			<?=form_open_multipart(base_url('List_admin/simpan_gambar'));?>
			    
				<label for="nama_ukmki">Nama ukm</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
					
				<label for="nama_ukmki">Jenis ukm</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
					
				<label for="nama_ukmki">Nama asli</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
					
				<label for="nama_ukmki">Nama panggilan</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
					
				<label for="nama_ukmki">Kontak Instagram</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
				
				<label for="nama_ukmki">Kontak Facebook</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
				
				<label for="nama_ukmki">Nomor whatsapp</label>
				<input type="text" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
					
									
				<label for="content">Penjelasan</label>
				<textarea name="content" cols="30" rows="10" placeholder="penjelasan"><?= $list->penjelasan ?></textarea>
				
				<label for="nama_ukmki">Logo umkm</label>
				<input type="file" name="nama_ukmki" 
					placeholder="Judul artikel" 
					required 
					title="nama umkm"
					value="<?= $list->nama_ukmki ?>"/>
			     <img src="<?= base_url('assets/images/' . $list->gambar_logo); ?>" width="150">
				<button type="submit" name="draft" class="button button-primary" value="false">Selanjutnya</button>
				</div>
			</form>

		</div>
	</main>
</body>

</html> 