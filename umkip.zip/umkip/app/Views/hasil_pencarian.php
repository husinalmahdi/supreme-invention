<!DOCTYPE html>
<html lang="en" class="no-js">
    <!-- BEGIN HEAD -->
    <head>
        <meta charset="utf-8"/>
        <title>UMKI (USAHA MIKRO KAMBANG IWAK)</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta content="width=device-width, initial-scale=1" name="viewport"/>
        <meta content="" name="description"/>
        <meta content="" name="author"/>
        <link rel="shortcut icon" href="/assets/images/logo.png">
    
        <link rel="stylesheet" href="<?php base_url();?>/css/style.css">
        
        <!-- GLOBAL MANDATORY STYLES -->
        <link href="http://fonts.googleapis.com/css?family=Hind:300,400,500,600,700" rel="stylesheet" type="text/css">
        <link href="../vendor/simple-line-icons/simple-line-icons.min.css" rel="stylesheet" type="text/css"/>
        <link href="../vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>

        <!-- PAGE LEVEL PLUGIN STYLES -->
        <link href="/css/animate.css" rel="stylesheet">
        <link href="/vendor/swiper/css/swiper.min.css" rel="stylesheet" type="text/css"/>
<link rel="stylesheet" href="/assets/css/style.css">
        <!-- THEME STYLES -->
        <link href="/css/layout.min.css" rel="stylesheet" type="text/css"/>

        <!-- Favicon -->
        <link rel="shortcut icon" href="favicon.ico"/>

        <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"> -->

<!-- jQuery library -->
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>

<!-- Popper JS -->
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.17.2/dist/sweetalert2.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@9.17.2/dist/sweetalert2.min.css"> -->
<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    </head>
    <!-- END HEAD -->

    <!-- BODY -->
    <body >

        <!--========== HEADER ==========-->
        <header class="header navbar-fixed-top">
            <!-- Navbar -->
            <nav class="navbar" role="navigation">
                <div class="container">
                    <!-- Brand and toggle get grouped for better mobile display -->
                    <div class="menu-container">
                        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".nav-collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="toggle-icon"></span>
                        </button>

                        <!-- Logo -->
                        <div class="logo">
                            <a class="logo-wrap" href="<?=base_url();?>">
                                <img class="logo-img logo-img-main" src="/assets/images/logo.png" alt="Logo umki-p">
                                <img class="logo-img logo-img-active" src="/assets/images/logo_darker.png" alt="Logo umki-p">
                            </a>
                        </div>
                        <!-- End Logo -->
                    </div>

                    <!-- Collect the nav links, forms, and other content for toggling -->
                    <div class="collapse navbar-collapse nav-collapse">
                        <div class="menu-container">
                            <ul class="navbar-nav navbar-nav-right">
                               
                                <li class="nav-item"><a class="nav-item-child nav-item-hover active" href="<?=base_url();?>">Home</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?=base_url('about');?>">About</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?=base_url('product');?>">Products</a></li>
                                <li class="nav-item"><a class="nav-item-child nav-item-hover" href="<?=base_url('faq');?>">FAQ</a></li>

                            </ul>
                            
                        </div>
                    </div>
                    
                    <!-- End Navbar Collapse -->
                </div>
            </nav>
            <!-- Navbar -->
        </header>

        <!--========== END HEADER ==========-->

        <!--========== SLIDER ==========-->
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
            <div class="container">
                <!-- Indicators -->
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                </ol>
            </div>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <div class="item active">
                    <img class="img-responsive" src="/img/1920x1080/01.jpg" alt="Slider Image">
                    <div class="container">
                        <div class="carousel-centered">
                            <div class="margin-b-40">
                                <div style="display:flex;">
                                <h1 class="carousel-title">UMKI-P</h1>
                     <form action="<?php echo base_url('home/cari')?>" action="GET">
                        <?= csrf_field(); ?>
                        <div class="flexbox">
                          <div class="search">
                            <div>
                              <input type="text" placeholder="Search . . ." value="Cari produk.." name="cari">

                            </div>
                          </div>
                        </div>
                      </form>
                      </div>
                                
                                <p>Usaha Mikro Kambang Iwak <br/> Cari tau banyak informasi terkait usaha mikro yang ada di kambang iwak melalui website kami</p>
                            </div>
                      
                        </div>
                    </div>
                </div>
                <div class="item">
                    <img class="img-responsive" src="/img/1920x1080/02.jpg" alt="Slider Image">
                    <div class="container">
                        <div class="carousel-centered">
                            <div class="margin-b-40">
                            <div style="display:flex;">
                                <h1 class="carousel-title">UMKI-P</h1>
                     <form action="<?php echo base_url('home/cari')?>" action="GET">
                        <?= csrf_field(); ?>
                        <div class="flexbox">
                          <div class="search">
                            <div>
                              <input type="text" placeholder="Search . . ." value="Cari produk.." name="cari">

                            </div>
                          </div>
                        </div>
                      </form>
                      </div>
                                <p>Usaha Mikro Kambang Iwak <br/> Segera daftarkan usaha anda agar lebih dikenal dan peroleh lebih banyak keuntungan!</p>
                                
                            </div>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
        <div class="content-lg container">
        <div class="row margin-b-40">
          
                    <h2 style="text-align:center;"><?php echo $hasil;?></h2>
    
            </div>
        <div class="row margin-b-50">
                <!-- Our Exceptional Solutions -->
                <?php foreach ($list as $row) {?>
                  
                
                <div class="col-sm-4 sm-margin-b-50">
                    <div class="margin-b-20">
                        <div class="wow zoomIn" data-wow-duration=".3" data-wow-delay=".1s" style=" height: 250px;overflow: hidden;position: relative;">
                            <img class="img-responsive" style="   position: absolute;
                    left: -1000%;
                    right: -1000%;
                    top: -1000%;
                    bottom: -1000%;
                    margin: auto;
                    min-height: 100%;
                    min-width: 100%;"src="<?= base_url('assets/images/' . $row['gambar_logo']); ?>" alt="Our Exceptional Solutions Image">
                        </div>
                    </div>
                    <h3><a href="#"><?=$row['nama_ukmki']?></a> <span class="text-uppercase margin-l-20"><?=$row['jenis_ukm']?></span></h3>
                    <p>                      <p class="fs-15 font-weight-normal">
                          <?php
         
       
                            ?><?= strip_tags(substr($row['penjelasan'], 0, 110))."...";?></p>
                    <a class="link" href="<?=base_url();?>/home/view/<?=$row['link']?>">Read More</a>
                </div>
           <?php }?>
        </div>
 
        </div>

        <!--========== FOOTER ==========-->
        


</div>

        <footer class="footer">
            <!-- Links -->
            <div class="footer-seperator">
                <div class="content-lg container">
                    <div class="row">
                        <div class="col-sm-2 sm-margin-b-50">
                            <!-- List -->
                            <ul class="list-unstyled footer-list">
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Home</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">About</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Products</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Faq</a></li>
                            </ul>
                            <!-- End List -->
                        </div>
                        <div class="col-sm-4 sm-margin-b-30">
                           
                            <ul class="list-unstyled footer-list">
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Twitter</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Facebook</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">Instagram</a></li>
                                <li class="footer-list-item"><a class="footer-list-link" href="#">YouTube</a></li>
                            </ul>
                          
                        </div>
                        <div class="col-sm-5 sm-margin-b-30">
                            <h2 class="color-white">Send Us A Note</h2>
                            <input type="text" class="form-control footer-input margin-b-20" placeholder="Name" required>
                            <input type="email" class="form-control footer-input margin-b-20" placeholder="Email" required>
                            <input type="text" class="form-control footer-input margin-b-20" placeholder="Phone" required>
                            <textarea class="form-control footer-input margin-b-30" rows="6" placeholder="Message" required></textarea>
                            <button type="submit" class="btn-theme btn-theme-sm btn-base-bg text-uppercase">Submit</button>
                        </div>
                    </div>
                    <!--// end row -->
                </div>
            </div>
            <!-- End Links -->

            <!-- Copyright -->
            <div class="content container">
                <div class="row">
                    <div class="col-xs-6">
                        <img class="footer-logo" src="/assets/images/logo.png" alt="Asentus Logo">
                    </div>
                    <div class="col-xs-6 text-right ">
                    <p class="margin-b-0"><a class="color-base fweight-700" href="http://keenthemes.com/preview/asentus/">UMKI-P</a> Copyright: <a class="color-base fweight-700" href="http://www.keenthemes.com/">Faculty of Engineering</a></p>
                    </div>
                </div>
                <!--// end row -->
            </div>
            
            <!-- End Copyright -->
        </footer>
        <!--========== END FOOTER ==========-->

        <!-- Back To Top -->
        <a href="javascript:void(0);" class="js-back-to-top back-to-top">Top</a>

        <!-- JAVASCRIPTS(Load javascripts at bottom, this will reduce page load time) -->
        <!-- CORE PLUGINS -->
        <script src="/vendor/jquery.min.js" type="text/javascript"></script>
        <script src="/vendor/jquery-migrate.min.js" type="text/javascript"></script>
        <script src="/vendor/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL PLUGINS -->
        <script src="/vendor/jquery.easing.js" type="text/javascript"></script>
        <script src="/vendor/jquery.back-to-top.js" type="text/javascript"></script>
        <script src="/vendor/jquery.smooth-scroll.js" type="text/javascript"></script>
        <script src="/vendor/jquery.wow.min.js" type="text/javascript"></script>
        <script src="/vendor/swiper/js/swiper.jquery.min.js" type="text/javascript"></script>
        <script src="/vendor/masonry/jquery.masonry.pkgd.min.js" type="text/javascript"></script>
        <script src="/vendor/masonry/imagesloaded.pkgd.min.js" type="text/javascript"></script>

        <!-- PAGE LEVEL SCRIPTS -->
        <script src="/js/layout.min.js" type="text/javascript"></script>
        <script src="/js/components/wow.min.js" type="text/javascript"></script>
        <script src="/js/components/swiper.min.js" type="text/javascript"></script>
        <script src="/js/components/masonry.min.js" type="text/javascript"></script>
        <script src=" https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
       
        <script src="/js/script.js"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9.17.2/dist/sweetalert2.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/sweetalert2@9.17.2/dist/sweetalert2.min.css">



        
    </body>
   
</html>